package com.example.demo.service;

public interface FortuneService {
    String getFortune();
}
