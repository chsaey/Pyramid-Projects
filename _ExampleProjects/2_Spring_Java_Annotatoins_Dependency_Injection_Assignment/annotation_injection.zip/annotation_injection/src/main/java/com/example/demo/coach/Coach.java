package com.example.demo.coach;

public interface Coach {
    String getDailyWorkout();
    String getDailyFortune();
}
