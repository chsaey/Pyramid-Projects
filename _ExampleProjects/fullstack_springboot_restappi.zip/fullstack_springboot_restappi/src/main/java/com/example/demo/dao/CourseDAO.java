package com.example.demo.dao;

import com.example.demo.entity.Course;
import java.util.List;

public interface CourseDAO {
    public List<Course> findAll();
    public Course findById(int theId);
    public void deleteById(int theId);
    public void save(Course theEmployee);
}
