package com.example.demo.service;

import com.example.demo.dao.CourseDAO;
import com.example.demo.entity.Course;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class CoursesServiceImpl implements CourseService{
    private CourseDAO courseDAO;

    @Autowired
    public CoursesServiceImpl(CourseDAO theCourseDAO) {
        courseDAO = theCourseDAO;
    }
    @Override
    @Transactional
    public List<Course> findAll() {
        return courseDAO.findAll();
    }

    @Override
    @Transactional
    public Course findById(int theId) {
        return courseDAO.findById(theId);
    }

    @Override
    @Transactional
    public void deleteById(int theId) {
        courseDAO.deleteById(theId);
    }

    @Override
    @Transactional
    public void save(Course theEmployee) {
        courseDAO.save(theEmployee);
    }

}
