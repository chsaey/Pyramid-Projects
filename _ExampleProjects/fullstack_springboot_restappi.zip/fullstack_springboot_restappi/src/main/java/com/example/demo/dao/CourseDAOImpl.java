package com.example.demo.dao;

import com.example.demo.entity.Course;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import javax.persistence.EntityManager;
import java.util.List;

@Repository
public class CourseDAOImpl implements CourseDAO{

    private EntityManager entityManager;

    @Autowired
    public CourseDAOImpl(EntityManager theEntityManager) {
        entityManager = theEntityManager;
    }

    @Override
    public List<Course> findAll() {
        // get the current hibernate session
        Session currentSession = entityManager.unwrap(Session.class);
        // create a query
        Query<Course> theQuery = currentSession.createQuery("from Course", Course.class);
        // execute query and get result list
        List<Course> courses = theQuery.getResultList();
        // return the results
        return courses;
    }

    @Override
    public Course findById(int theId) {
        //Get the current hibernate session
        Session currentSession = entityManager.unwrap(Session.class);
        //Get the employee
        Course theCourse = currentSession.get(Course.class, theId);
        //Return the employee
        return theCourse;
    }

    @Override
    public void deleteById(int theId) {
        //Get the current hibernate session
        Session currentSession = entityManager.unwrap(Session.class);
        //Delete object with primary key
        Query theQuery = currentSession.createQuery("delete from Course where id=:courseId");
        theQuery.setParameter("courseId", theId);
        theQuery.executeUpdate();
    }

    @Override
    public void save(Course theCourse) {
        //Get the current hibernate session
        Session currentSession = entityManager.unwrap(Session.class);
        //Save Course
        currentSession.saveOrUpdate(theCourse); //if the id is 0 it will save/insert else it will update
    }
}
