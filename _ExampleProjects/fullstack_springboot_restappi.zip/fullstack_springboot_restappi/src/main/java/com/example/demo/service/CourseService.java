package com.example.demo.service;

import com.example.demo.entity.Course;
import java.util.List;

public interface CourseService {
    public List<Course> findAll();
    public Course findById(int theId);
    public void deleteById(int theId);
    public void save(Course theEmployee);
}
