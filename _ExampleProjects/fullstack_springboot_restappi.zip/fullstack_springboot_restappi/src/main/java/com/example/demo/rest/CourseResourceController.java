package com.example.demo.rest;

import com.example.demo.entity.Course;
import com.example.demo.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:4200"})
@RestController
public class CourseResourceController {

    @Autowired
    private CourseService courseService;

    //test controller
    @GetMapping("/courses")
    public List<Course> findAll() {
        return courseService.findAll();
    }

    //mapping for getting all the courses
    @GetMapping("/instructors/{username}/courses")
    public List<Course> getAllCourse(@PathVariable String username) {
        return courseService.findAll();
    }

    //Mapping to retrieve a course by id
    @GetMapping("/instructors/{username}/courses/{courseId}")
    public Course getEmployee(@PathVariable int courseId) {
        Course theCourse = courseService.findById(courseId);
        if(theCourse == null) {
            throw new RuntimeException("Course id not found - " + courseId);
        }
        return theCourse;
    }

    //Mapping to delete a course.
    @DeleteMapping("/instructors/{username}/courses/{courseId}")
    public String deleteCourseById(@PathVariable int courseId) {
        Course tempCourse = courseService.findById(courseId);
        //throw exception if null
        if(tempCourse == null) {
            throw new RuntimeException("Course is not found - " + courseId);
        }
        courseService.deleteById(courseId);
        return "Deleted course id - " + courseId;
    }

    //This is a PUT request to update an existing course.
    @PutMapping("/instructors/{username}/courses/{id}")
    public Course updateCourse(@RequestBody Course theCourse) {
        courseService.save(theCourse);
        return theCourse;
    }

    //This is a POST request to add a new employee.
    @PostMapping("/instructors/{username}/courses")
    public Course addCourse(@RequestBody Course theCourse) {
        theCourse.setId(0);
        courseService.save(theCourse);
        return theCourse;
    }
}
