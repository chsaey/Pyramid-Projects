import React, {Component} from 'react';
import ListCoursesComponent from './ListCoursesComponent';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import CourseComponent from './CourseComponent';
import WelcomeComponent from './WelcomeComponent';

class InstructorApp extends Component {
    render() {
        return (
            <Router>
                <>
                <h1>Courses Application</h1>
                <Switch>
                    <Route path="/" exact component={WelcomeComponent} />
                    <Route path="/courses" exact component={ListCoursesComponent} />
                    <Route path="/courses/:id" exact component={CourseComponent} />
               </Switch>
                </>
            </Router>
      )
  }
}
export default InstructorApp