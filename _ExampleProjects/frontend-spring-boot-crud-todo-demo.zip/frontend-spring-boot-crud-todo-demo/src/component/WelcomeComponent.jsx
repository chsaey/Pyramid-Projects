import React, { Component } from 'react'
import {Link} from 'react-router-dom'

class WelcomeComponent extends Component {
    render() {
        return(
            <div className="container">
                <br></br>
               <h1>Welcome!!!</h1>
               <h2>You can manage your Courses here: <Link to="/courses">Here</Link>.</h2>
            </div>
        )
    }
}
export default WelcomeComponent