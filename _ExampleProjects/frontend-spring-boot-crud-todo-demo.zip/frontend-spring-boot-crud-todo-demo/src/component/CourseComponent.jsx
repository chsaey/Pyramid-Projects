import React, { Component } from 'react'
import {Formik, Form, Field} from 'formik';
import CourseDataService from '../service/CourseDataService';

const INSTRUCTOR = 'Pyramid'

class CourseComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {
            id: this.props.match.params.id,
            username: INSTRUCTOR,
            description: ''
        }
        this.onSubmit = this.onSubmit.bind(this)
    }
    componentDidMount() {
        console.log(this.state.id)
        //eslint-disable-next-line
        if(this.state.id == -1) {
            return 
        }
        CourseDataService.retrieveCourse(INSTRUCTOR, this.state.id)
        .then(response => this.setState({
            description: response.data.description
        }))
    }
    onSubmit(values) {
        let username = INSTRUCTOR
        let course = {
            id: this.state.id,
            description: values.description
        }
        
        
        if(this.state.id === "-1"){
            CourseDataService.createCourse(username, course)
                .then (() => this.props.history.push('/courses'))
        } else {
            CourseDataService.updateCourse(this.state.id, username, course)
                .then(() => this.props.history.push('/courses'))
        }
        console.log(values);
    }

    render() {
        let {id, username, description} = this.state
        
        return (
                <div>
                    <h3>Course</h3>
                    <div className="container">
                        <Formik
                            initialValues={{id,username,description}}
                            onSubmit={this.onSubmit}
                            enableReinitialize={true}
                        >
                            {
                                (props) => (
                                    <Form>
                                        <fieldset className="form-group">
                                            <label>Id</label>
                                            <Field className="form-control" type="text" name="id" disabled />
                                        </fieldset>
                                        <fieldset className="form-group">
                                            <label>Description</label>
                                            <Field className="form-control" type="text" name="description"  />
                                        </fieldset>
                                        <button className="btn btn-success" type="submit">Save</button>
                                    </Form>
                                )
                            }

                        </Formik>
                    </div>
                </div>
        )
    }
}
export default CourseComponent